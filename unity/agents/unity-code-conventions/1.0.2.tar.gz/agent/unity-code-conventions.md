---
name: unity-code-conventions
description: Unity conventions, module structure, and stack guidance for this repo. Use when implementing, testing, reviewing, or updating Unity-focused prompts and workflows here.
---

# Unity Conventions

This skill is the repo-local single source of truth for generic Unity conventions.
It is intentionally generic and must not be derived from current repo code.

## Use This Skill When
- implementing Unity runtime or editor work
- testing or reviewing Unity changes
- updating Unity-focused repo-local opencode prompts or workflows

## Operating Rules
- Treat this skill as guidance within the approved task scope only.
- Do not use this skill to justify unrelated refactors, package churn, or architecture rewrites.
- If following these conventions would require broader rework than the approved task allows, stop and return to planning.
- If repo reality materially conflicts with these conventions, surface the conflict instead of silently working around it.

## Code Conventions
- Use `#nullable enable`.
- Write XML docs only for interface, public, or protected API.
- Access modifiers must be explicit on every member (field, method, property, event, const). Never rely on implicit accessibility.
- Members that are not part of the class's external API must be declared `private` explicitly (including Unity lifecycle callbacks and event handlers used only within the class).
- Qualify ALL instance member access inside a class with `this.` — fields, properties, method calls, and event subscribe/raise (`this.Method()`, `this.field`, `this.OnRefreshed?.Invoke()`). Exclude `static`, `base.`, and interface-explicit (`IFoo.Bar`) access.
- Unity-serialized data fields use `[SerializeField] private` and are exposed through a read-only `public ... Prop => field;` getter when read outside the type.
- Config data records (loaded via `IDataManager` / `IConfigData` / CSV tables) expose read-only members with private write — `public T Field { get; private set; }` — and a public parameterless constructor. No public setters or mutable public fields on config data; config is immutable after load. Services that consume config tables cache the loaded table in a private field (load once via `IDataManager`, then read synchronously).
- Default to `internal` visibility for types (interfaces, classes, structs) not consumed as public API.
- Default to `sealed` types unless extension is required.
- Use `static` only for stateless helpers.
- Keep one top-level type per file.
- Do not place `UnityEditor` references in runtime code.
- Use `#if UNITY_EDITOR` only for small runtime-adjacent hooks, not as a substitute for proper assembly separation.
- Avoid per-frame allocations in hot paths.
- Avoid alloc-heavy LINQ or ZLinq usage in hot paths.

## C# Language Conventions
- `var`: use `var` for all locals (type inferred). Reserve explicit types for public/API-visible signatures (returns, parameters, public fields/properties).
- `using` directives: group and sort — `System.*` first, third-party next, project (`Roguelike.*`) last. Use aliases only to resolve ambiguity (`using Object = UnityEngine.Object;`), never for brevity. Avoid `using static` except for constants, enums, and `Math`.
- `using` statements: always use `using (...)` blocks so dispose scope is explicit. Always dispose `IAssetHandle` inside the block (releases the Addressables refcount) and read `handle.Asset` within the block.
- Null handling: use `is null` / `is not null` for reference checks. Do not null-check in constructors — DI (VContainer) guarantees injected dependencies; assign params directly. Guard public method params with `ArgumentNullException` + `nameof(...)`; use `ArgumentOutOfRangeException` for range/switch-default violations.
- Expression-bodied members: use `=>` for single-expression bodies.
- Target-typed `new`: prefer `new()` when the target type is clear.
- Switch expressions: prefer over switch statements; throw `ArgumentOutOfRangeException` for the default arm.
- String building: always `$""` interpolation; no `+` concatenation or `string.Format`.
- Collections API: expose `IReadOnlyList<T>` / `IReadOnlyCollection<T>` / `IEnumerable<T>`; avoid mutable `List<T>` in public API. Mark fields `readonly`.
- Async naming: suffix async methods with `*Async`. Do not use `ConfigureAwait` in Unity code.
- Namespaces: use block namespaces (`namespace Roguelike.X { ... }`); no file-scoped namespaces.

## Structure Conventions
- Organize work as full feature modules.
- Use per-feature asmdefs by default.
- Use namespaces in the shape of `Project`, `Project.Feature`, `Project.Editor`, and `Project.Editor.Feature`.
- Runtime feature folders should normally use:
  - `Api/`
  - `Data/`
  - `Services/`
  - `Systems/`
  - `Presentation/`
- Keep `MonoBehaviour` classes thin.
- If a contract needs a GameObject as a view source, implement a thin `MonoBehaviour` that maps the view from the editor (serialized fields / prefab reference, wired with `RegisterComponent`). Do not create or build views procedurally in code.
- Use `ScriptableObject` for configuration and authoring-time behavior.
- `Services` contain business or application logic.
- `Systems` contain ticking or orchestration logic.
- `Api` contains contracts, facades, and events only.

## Stack Guidance
- Unity 6
- URP
- Odin
- VContainer
- MessagePipe
- UniTask
- ZLinq
- LitMotion

## Usage Rules
- Prefer broad VContainer usage for composition.
- MessagePipe is acceptable inside a feature.
- Use UniTask in runtime code by default.
- Odin can be used broadly, but core runtime architecture should not depend on it.
- ZLinq is acceptable generally, but never in hot paths.
- Use LitMotion for UI, presentation, and gameplay animation.

## Block And Return Conditions
Stop and return when the approved task would require any of the following:
- a runtime/editor boundary violation
- a structure conflict that needs broader rework
- repo reality materially conflicting with the approved conventions

If the issue is a same-scope implementation defect, return to the builder.
If the issue needs scope, structure, or architecture changes, return to the planner.
