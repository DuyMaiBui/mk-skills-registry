---
name: plan
description: Create phased implementation plans with clear scope and acceptance criteria.
---

# plan

## Use This Skill When
- plan this feature
- how should we build this
- create implementation plan
- break this down

## Rules
- Start from approved scope.
- Define acceptance criteria.
- Keep plans executable.
- For every implementable code step, define its input (parameters, data, or preconditions) and its output (return value or resulting effect).
- For every implementable code step, require a unit test that verifies the defined output for the defined inputs.
- Acceptance criteria must include passing unit tests as done criteria.
